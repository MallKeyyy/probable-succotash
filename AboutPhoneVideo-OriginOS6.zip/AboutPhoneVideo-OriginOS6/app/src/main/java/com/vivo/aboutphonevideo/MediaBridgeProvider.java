package com.vivo.aboutphonevideo;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

public class MediaBridgeProvider extends ContentProvider {
    public static final String AUTHORITY = "com.vivo.aboutphonevideo.provider";
    public static final Uri URI_CONFIG = Uri.parse("content://" + AUTHORITY);
    public static final Uri URI_CARD_VIDEO = Uri.parse("content://" + AUTHORITY + "/card_video");
    public static final Uri URI_BG_VIDEO = Uri.parse("content://" + AUTHORITY + "/bg_video");
    public static final String METHOD_GET_CONFIG = "getConfig";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Context ctx = getContext();
        if (ctx == null) return null;
        if (METHOD_GET_CONFIG.equals(method)) {
            return ConfigStore.toBundle(ctx);
        }
        return null;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        Context ctx = getContext();
        if (ctx == null) throw new FileNotFoundException("No context");
        String path = uri.getPath();
        File target;
        if ("/card_video".equals(path)) {
            target = ConfigStore.getCardVideoFile(ctx);
        } else if ("/bg_video".equals(path)) {
            target = ConfigStore.getBgVideoFile(ctx);
        } else {
            throw new FileNotFoundException("Unknown URI: " + uri);
        }
        if (!target.exists() || target.length() == 0) {
            throw new FileNotFoundException("Video not configured: " + target.getName());
        }
        return ParcelFileDescriptor.open(target, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return "video/mp4";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
