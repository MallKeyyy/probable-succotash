package com.vivo.aboutphonevideo;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookEntry implements IXposedHookLoadPackage {
    private static final String SETTINGS_PKG = "com.android.settings";
    private static final String FRAGMENT_CLASS = "com.vivo.settings.aboutphone.deviceinfo.VivoAboutPhoneFragment";
    private static final String DEVICE_INFO_LAYOUT_CLASS = "com.vivo.settings.aboutphone.deviceinfo.VivoDeviceInfoLayout";

    private static final String TAG_CARD_OVERLAY = "apv_card_video_overlay";
    private static final String TAG_BG_LAYER = "apv_bg_video_layer";
    private static final String TAG_ROM_IMAGE_MARK = "apv_rom_image_target";

    private static final String[] ROM_DRAWABLE_NAMES = new String[] {
            "about_phone_origin_os_rom16",
            "about_phone_origin_os_rom",
            "about_phone_rom15"
    };

    private final Set<Integer> romDrawableIds = new HashSet<>();
    private final Set<Drawable> romDrawables = Collections.newSetFromMap(new WeakHashMap<>());
    private boolean romIdsResolved = false;

    private WeakReference<VideoSurfaceView> activeCardVideo = new WeakReference<>(null);
    private WeakReference<VideoSurfaceView> activeBgVideo = new WeakReference<>(null);
    private WeakReference<View> activeBgLayer = new WeakReference<>(null);

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!SETTINGS_PKG.equals(lpparam.packageName)) return;
        XposedBridge.log("[AboutPhoneVideo] Loaded in com.android.settings");

        hookDrawableLoadingAndViews();
        hookAboutPhoneFragment(lpparam.classLoader);
    }

    private void ensureRomIdsResolved(Context context) {
        if (romIdsResolved || context == null) return;
        romIdsResolved = true;
        for (String name : ROM_DRAWABLE_NAMES) {
            int id = context.getResources().getIdentifier(name, "drawable", SETTINGS_PKG);
            if (id != 0) {
                romDrawableIds.add(id);
                XposedBridge.log("[AboutPhoneVideo] Resolved " + name + " -> 0x" + Integer.toHexString(id));
            }
        }
    }

    private void hookDrawableLoadingAndViews() {
        try {
            XposedBridge.hookAllMethods(Resources.class, "getDrawable", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args.length > 0 && param.args[0] instanceof Integer) {
                        int id = (int) param.args[0];
                        if (id != 0 && romDrawableIds.contains(id) && param.getResult() instanceof Drawable) {
                            romDrawables.add((Drawable) param.getResult());
                        }
                    }
                }
            });
            XposedBridge.hookAllMethods(Resources.class, "getDrawableForDensity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args.length > 0 && param.args[0] instanceof Integer) {
                        int id = (int) param.args[0];
                        if (id != 0 && romDrawableIds.contains(id) && param.getResult() instanceof Drawable) {
                            romDrawables.add((Drawable) param.getResult());
                        }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("[AboutPhoneVideo] Resources hook warning: " + t.getMessage());
        }

        try {
            XposedHelpers.findAndHookMethod(ImageView.class, "setImageResource", int.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    ImageView iv = (ImageView) param.thisObject;
                    int resId = (int) param.args[0];
                    ensureRomIdsResolved(iv.getContext());
                    if (resId != 0 && romDrawableIds.contains(resId)) {
                        iv.setTag(TAG_ROM_IMAGE_MARK);
                    }
                }
            });
            XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", Drawable.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    ImageView iv = (ImageView) param.thisObject;
                    Drawable d = (Drawable) param.args[0];
                    if (d != null && romDrawables.contains(d)) {
                        iv.setTag(TAG_ROM_IMAGE_MARK);
                    }
                }
            });
            XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    View v = (View) param.thisObject;
                    Drawable d = (Drawable) param.args[0];
                    if (d != null && romDrawables.contains(d)) {
                        v.setTag(TAG_ROM_IMAGE_MARK);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("[AboutPhoneVideo] View hook warning: " + t.getMessage());
        }
    }

    private void hookAboutPhoneFragment(ClassLoader classLoader) {
        Class<?> fragClass = XposedHelpers.findClassIfExists(FRAGMENT_CLASS, classLoader);
        if (fragClass == null) {
            XposedBridge.log("[AboutPhoneVideo] VivoAboutPhoneFragment not found");
            return;
        }

        XposedBridge.hookAllMethods(fragClass, "onViewCreated", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                if (param.args.length == 0 || !(param.args[0] instanceof View)) return;
                View rootView = (View) param.args[0];
                Object fragment = param.thisObject;

                rootView.post(() -> applyAllHooks(fragment, rootView));
                rootView.postDelayed(() -> applyAllHooks(fragment, rootView), 250L);
                rootView.postDelayed(() -> applyAllHooks(fragment, rootView), 700L);

                rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (rootView.findViewWithTag(TAG_CARD_OVERLAY) != null) {
                            rootView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            return;
                        }
                        applyAllHooks(fragment, rootView);
                    }
                });
            }
        });

        XposedBridge.hookAllMethods(fragClass, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                VideoSurfaceView card = activeCardVideo.get();
                if (card != null) card.resumePlayback();
                VideoSurfaceView bg = activeBgVideo.get();
                if (bg != null) bg.resumePlayback();
            }
        });

        XposedBridge.hookAllMethods(fragClass, "onPause", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                VideoSurfaceView card = activeCardVideo.get();
                if (card != null) card.pausePlayback();
                VideoSurfaceView bg = activeBgVideo.get();
                if (bg != null) bg.pausePlayback();
            }
        });

        XposedBridge.hookAllMethods(fragClass, "onDestroyView", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                cleanupBackgroundLayer();
                VideoSurfaceView card = activeCardVideo.get();
                if (card != null) {
                    card.releasePlayer();
                    activeCardVideo = new WeakReference<>(null);
                }
            }
        });
    }

    private Bundle loadConfig(Context context) {
        try {
            return context.getContentResolver().call(
                    MediaBridgeProvider.URI_CONFIG,
                    MediaBridgeProvider.METHOD_GET_CONFIG,
                    null,
                    null
            );
        } catch (Throwable t) {
            XposedBridge.log("[AboutPhoneVideo] Failed to read config via provider: " + t.getMessage());
            return null;
        }
    }

    private void applyAllHooks(Object fragment, View fragmentRoot) {
        Context context = fragmentRoot.getContext();
        if (context == null) return;
        ensureRomIdsResolved(context);

        Bundle cfg = loadConfig(context);
        if (cfg == null) return;

        if (cfg.getBoolean(ConfigStore.KEY_CARD_ENABLED, false) && cfg.getBoolean("card_has_video", false)) {
            attachCardVideo(fragmentRoot, cfg);
        }

        if (cfg.getBoolean(ConfigStore.KEY_BG_ENABLED, false) && cfg.getBoolean("bg_has_video", false)) {
            Activity activity = null;
            try {
                activity = (Activity) XposedHelpers.callMethod(fragment, "getActivity");
            } catch (Throwable ignored) {}
            attachBackgroundVideo(activity, fragmentRoot, cfg);
        }
    }

    private void attachCardVideo(View fragmentRoot, Bundle cfg) {
        if (fragmentRoot.findViewWithTag(TAG_CARD_OVERLAY) != null) return;

        View target = findRomCardView(fragmentRoot);
        if (target == null || !(target.getParent() instanceof ViewGroup)) {
            return;
        }

        ViewGroup parent = (ViewGroup) target.getParent();
        Context ctx = target.getContext();
        int cornerPx = dpToPx(ctx, cfg.getInt(ConfigStore.KEY_CARD_CORNER_DP, 18));

        FrameLayout wrapper = new FrameLayout(ctx);
        wrapper.setTag(TAG_CARD_OVERLAY);
        wrapper.setClipToOutline(true);
        wrapper.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), cornerPx);
            }
        });

        VideoSurfaceView videoView = new VideoSurfaceView(
                ctx,
                MediaBridgeProvider.URI_CARD_VIDEO,
                cfg.getBoolean(ConfigStore.KEY_CARD_MUTED, true),
                cfg.getInt(ConfigStore.KEY_CARD_VOLUME, 60)
        );
        wrapper.addView(videoView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        int index = parent.indexOfChild(target);
        ViewGroup.LayoutParams lp = target.getLayoutParams();
        if (lp == null) {
            lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(ctx, 180));
        }

        if (target instanceof ImageView) {
            ((ImageView) target).setImageDrawable(null);
        } else {
            target.setVisibility(View.INVISIBLE);
        }

        if (parent instanceof FrameLayout) {
            parent.addView(wrapper, index + 1, new FrameLayout.LayoutParams(lp.width, lp.height));
        } else {
            parent.removeViewAt(index);
            FrameLayout slot = new FrameLayout(ctx);
            slot.setId(target.getId());
            target.setId(View.NO_ID);
            slot.addView(target, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            slot.addView(wrapper, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            parent.addView(slot, index, lp);
        }

        activeCardVideo = new WeakReference<>(videoView);
        XposedBridge.log("[AboutPhoneVideo] Attached card video overlay on " + target.getClass().getSimpleName());
    }

    private View findRomCardView(View root) {
        List<View> allViews = new ArrayList<>();
        collectAllViews(root, allViews);

        // Pass 1: Explicitly marked by setImageResource / setImageDrawable / setBackground
        for (View v : allViews) {
            if (TAG_ROM_IMAGE_MARK.equals(v.getTag())) {
                return v;
            }
        }

        // Pass 2: Match resource ID name heuristics (rom / origin / banner / os_img)
        for (View v : allViews) {
            if (v instanceof ImageView && v.getId() != View.NO_ID) {
                try {
                    String name = v.getResources().getResourceEntryName(v.getId()).toLowerCase();
                    if (name.contains("rom") || name.contains("origin") || name.contains("banner") || name.contains("os_img")) {
                        return v;
                    }
                } catch (Throwable ignored) {}
            }
        }

        // Pass 3: Largest wide ImageView in the upper half of the screen (OriginOS card is ~936x618)
        int screenW = root.getResources().getDisplayMetrics().widthPixels;
        View best = null;
        int bestArea = 0;
        for (View v : allViews) {
            if (!(v instanceof ImageView)) continue;
            int w = v.getWidth();
            int h = v.getHeight();
            if (w >= screenW * 0.55f && h >= dpToPx(root.getContext(), 110) && w > h && h <= dpToPx(root.getContext(), 320)) {
                int area = w * h;
                if (area > bestArea) {
                    bestArea = area;
                    best = v;
                }
            }
        }
        return best;
    }

    private void collectAllViews(View v, List<View> out) {
        out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collectAllViews(vg.getChildAt(i), out);
            }
        }
    }

    private void attachBackgroundVideo(Activity activity, View fragmentRoot, Bundle cfg) {
        if (activity == null) return;
        ViewGroup contentRoot = activity.findViewById(android.R.id.content);
        if (contentRoot == null) return;
        if (contentRoot.findViewWithTag(TAG_BG_LAYER) != null) return;

        Context ctx = activity;
        FrameLayout bgLayer = new FrameLayout(ctx);
        bgLayer.setTag(TAG_BG_LAYER);

        VideoSurfaceView bgVideo = new VideoSurfaceView(
                ctx,
                MediaBridgeProvider.URI_BG_VIDEO,
                cfg.getBoolean(ConfigStore.KEY_BG_MUTED, true),
                cfg.getInt(ConfigStore.KEY_BG_VOLUME, 40)
        );
        bgLayer.addView(bgVideo, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        int dimPercent = Math.max(0, Math.min(85, cfg.getInt(ConfigStore.KEY_BG_DIM_ALPHA, 35)));
        View scrim = new View(ctx);
        scrim.setBackgroundColor(Color.argb((int) (dimPercent * 2.55f), 0, 0, 0));
        bgLayer.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        contentRoot.addView(bgLayer, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        if (activity.getWindow() != null) {
            activity.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        int cardAlphaPercent = Math.max(20, Math.min(100, cfg.getInt(ConfigStore.KEY_BG_CARD_ALPHA, 75)));
        makeContainersTransparent(fragmentRoot, cardAlphaPercent / 100f);

        View cur = fragmentRoot;
        while (cur != null && cur != contentRoot) {
            cur.setBackgroundColor(Color.TRANSPARENT);
            if (cur.getParent() instanceof View) {
                cur = (View) cur.getParent();
            } else {
                break;
            }
        }

        activeBgVideo = new WeakReference<>(bgVideo);
        activeBgLayer = new WeakReference<>(bgLayer);
        XposedBridge.log("[AboutPhoneVideo] Attached About Phone background video");
    }

    private void makeContainersTransparent(View view, float cardAlpha) {
        if (view == null) return;
        String cls = view.getClass().getName();
        if (TAG_CARD_OVERLAY.equals(view.getTag()) || TAG_BG_LAYER.equals(view.getTag())) {
            return;
        }
        if (cls.equals(DEVICE_INFO_LAYOUT_CLASS)) {
            Drawable bg = view.getBackground();
            if (bg != null) {
                bg.mutate().setAlpha((int) (cardAlpha * 255));
            }
        } else if (view instanceof ViewGroup) {
            String lower = cls.toLowerCase();
            if (lower.contains("recyclerview") || lower.contains("scrollview")
                    || lower.contains("coordinator") || lower.contains("appbar")
                    || lower.contains("collapsing") || lower.contains("framelayout")
                    || lower.contains("linearlayout")) {
                if (view.getBackground() instanceof ColorDrawable) {
                    view.setBackgroundColor(Color.TRANSPARENT);
                }
            }
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                makeContainersTransparent(vg.getChildAt(i), cardAlpha);
            }
        }
    }

    private void cleanupBackgroundLayer() {
        VideoSurfaceView bg = activeBgVideo.get();
        if (bg != null) {
            bg.releasePlayer();
            activeBgVideo = new WeakReference<>(null);
        }
        View layer = activeBgLayer.get();
        if (layer != null && layer.getParent() instanceof ViewGroup) {
            ((ViewGroup) layer.getParent()).removeView(layer);
            activeBgLayer = new WeakReference<>(null);
        }
    }

    private int dpToPx(Context ctx, int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, ctx.getResources().getDisplayMetrics());
    }
}
