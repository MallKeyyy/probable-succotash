package com.vivo.aboutphonevideo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int REQ_PICK_CARD_VIDEO = 1001;
    private static final int REQ_PICK_BG_VIDEO = 1002;

    private TextView cardStatusText;
    private TextView bgStatusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupEdgeToEdge();
        setContentView(buildLiquidGlassUi());
        refreshVideoStatuses();
    }

    private void setupEdgeToEdge() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(Color.parseColor("#0A0F1F"));
        w.setNavigationBarColor(Color.parseColor("#0A0F1F"));
    }

    private View buildLiquidGlassUi() {
        FrameLayout root = new FrameLayout(this);
        root.addView(new AmbientOrbBackground(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, dp(42), pad, dp(36));

        // Header
        TextView title = new TextView(this);
        title.setText("About Phone Video");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        content.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("OriginOS 6 • Companion module for Vivo Tool");
        subtitle.setTextColor(Color.parseColor("#B8C7E8"));
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        subtitle.setPadding(0, dp(4), 0, dp(22));
        content.addView(subtitle);

        SharedPreferences sp = ConfigStore.prefs(this);

        // Card 1: About Phone Card Image Video
        LinearLayout card1 = createGlassCard();
        card1.addView(createCardTitle("About Phone Image Video"));
        card1.addView(createCardDesc("Replaces the stock about_phone_origin_os_rom16 banner with a looping video."));

        card1.addView(createSwitchRow("Enable card video",
                sp.getBoolean(ConfigStore.KEY_CARD_ENABLED, true),
                checked -> sp.edit().putBoolean(ConfigStore.KEY_CARD_ENABLED, checked).apply()));

        cardStatusText = createStatusChip();
        card1.addView(cardStatusText);

        LinearLayout cardBtnRow = new LinearLayout(this);
        cardBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        cardBtnRow.setPadding(0, dp(10), 0, dp(12));
        cardBtnRow.addView(createPillButton("Pick Video", "#4E8CFF", v -> pickVideo(REQ_PICK_CARD_VIDEO)));
        View spacer1 = new View(this);
        cardBtnRow.addView(spacer1, new LinearLayout.LayoutParams(dp(10), 1));
        cardBtnRow.addView(createPillButton("Clear", "#33FFFFFF", v -> clearVideo(true)));
        card1.addView(cardBtnRow);

        card1.addView(createSwitchRow("Mute card video",
                sp.getBoolean(ConfigStore.KEY_CARD_MUTED, true),
                checked -> sp.edit().putBoolean(ConfigStore.KEY_CARD_MUTED, checked).apply()));

        card1.addView(createSliderRow("Card volume", "%",
                sp.getInt(ConfigStore.KEY_CARD_VOLUME, 60), 100,
                val -> sp.edit().putInt(ConfigStore.KEY_CARD_VOLUME, val).apply()));

        card1.addView(createSliderRow("Corner radius", "dp",
                sp.getInt(ConfigStore.KEY_CARD_CORNER_DP, 18), 36,
                val -> sp.edit().putInt(ConfigStore.KEY_CARD_CORNER_DP, val).apply()));

        content.addView(card1, cardLayoutParams());

        // Card 2: About Phone Full Background Video
        LinearLayout card2 = createGlassCard();
        card2.addView(createCardTitle("About Phone Background Video"));
        card2.addView(createCardDesc("Plays a full-screen looping video behind the About Phone page with readable dim & glass cards."));

        card2.addView(createSwitchRow("Enable background video",
                sp.getBoolean(ConfigStore.KEY_BG_ENABLED, true),
                checked -> sp.edit().putBoolean(ConfigStore.KEY_BG_ENABLED, checked).apply()));

        bgStatusText = createStatusChip();
        card2.addView(bgStatusText);

        LinearLayout bgBtnRow = new LinearLayout(this);
        bgBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        bgBtnRow.setPadding(0, dp(10), 0, dp(12));
        bgBtnRow.addView(createPillButton("Pick Video", "#8B6BFF", v -> pickVideo(REQ_PICK_BG_VIDEO)));
        View spacer2 = new View(this);
        bgBtnRow.addView(spacer2, new LinearLayout.LayoutParams(dp(10), 1));
        bgBtnRow.addView(createPillButton("Clear", "#33FFFFFF", v -> clearVideo(false)));
        card2.addView(bgBtnRow);

        card2.addView(createSwitchRow("Mute background video",
                sp.getBoolean(ConfigStore.KEY_BG_MUTED, true),
                checked -> sp.edit().putBoolean(ConfigStore.KEY_BG_MUTED, checked).apply()));

        card2.addView(createSliderRow("Background volume", "%",
                sp.getInt(ConfigStore.KEY_BG_VOLUME, 40), 100,
                val -> sp.edit().putInt(ConfigStore.KEY_BG_VOLUME, val).apply()));

        card2.addView(createSliderRow("Dark scrim dim", "%",
                sp.getInt(ConfigStore.KEY_BG_DIM_ALPHA, 35), 85,
                val -> sp.edit().putInt(ConfigStore.KEY_BG_DIM_ALPHA, val).apply()));

        card2.addView(createSliderRow("Info card opacity", "%",
                sp.getInt(ConfigStore.KEY_BG_CARD_ALPHA, 75), 100,
                val -> sp.edit().putInt(ConfigStore.KEY_BG_CARD_ALPHA, Math.max(20, val)).apply()));

        content.addView(card2, cardLayoutParams());

        // Card 3: How to apply
        LinearLayout card3 = createGlassCard();
        card3.addView(createCardTitle("How to Apply"));
        card3.addView(createCardDesc(
                "1. Enable this module in LSPosed and select System Settings (com.android.settings).\n" +
                "2. Pick your Card Video and/or Background Video above.\n" +
                "3. Force stop Settings and open Settings → About phone."
        ));
        content.addView(card3, cardLayoutParams());

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    private void pickVideo(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        startActivityForResult(intent, requestCode);
    }

    private void clearVideo(boolean isCard) {
        File f = isCard ? ConfigStore.getCardVideoFile(this) : ConfigStore.getBgVideoFile(this);
        if (f.exists()) f.delete();
        refreshVideoStatuses();
        Toast.makeText(this, isCard ? "Card video cleared" : "Background video cleared", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        boolean isCard = (requestCode == REQ_PICK_CARD_VIDEO);
        File dst = isCard ? ConfigStore.getCardVideoFile(this) : ConfigStore.getBgVideoFile(this);

        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new IllegalStateException("Cannot open video stream");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                out.flush();
                runOnUiThread(() -> {
                    refreshVideoStatuses();
                    Toast.makeText(this,
                            (isCard ? "Card video saved" : "Background video saved") + " — force stop Settings to apply",
                            Toast.LENGTH_LONG).show();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Copy failed: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void refreshVideoStatuses() {
        File card = ConfigStore.getCardVideoFile(this);
        if (card.exists() && card.length() > 0) {
            cardStatusText.setText("Selected: " + formatSize(card.length()));
            cardStatusText.setTextColor(Color.parseColor("#8CF0B6"));
        } else {
            cardStatusText.setText("No card video selected");
            cardStatusText.setTextColor(Color.parseColor("#9FB0CF"));
        }

        File bg = ConfigStore.getBgVideoFile(this);
        if (bg.exists() && bg.length() > 0) {
            bgStatusText.setText("Selected: " + formatSize(bg.length()));
            bgStatusText.setTextColor(Color.parseColor("#8CF0B6"));
        } else {
            bgStatusText.setText("No background video selected");
            bgStatusText.setTextColor(Color.parseColor("#9FB0CF"));
        }
    }

    private String formatSize(long bytes) {
        double mb = bytes / (1024.0 * 1024.0);
        return String.format(java.util.Locale.US, "%.2f MB", mb);
    }

    private LinearLayout createGlassCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = dp(18);
        card.setPadding(p, p, p, p);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(24));
        bg.setColor(Color.argb(42, 255, 255, 255));
        bg.setStroke(dp(1), Color.argb(72, 255, 255, 255));
        card.setBackground(bg);
        return card;
    }

    private LinearLayout.LayoutParams cardLayoutParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(16);
        return lp;
    }

    private TextView createCardTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        return tv;
    }

    private TextView createCardDesc(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#B6C5E2"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setPadding(0, dp(4), 0, dp(10));
        return tv;
    }

    private TextView createStatusChip() {
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(14));
        gd.setColor(Color.argb(35, 0, 0, 0));
        tv.setBackground(gd);
        return tv;
    }

    private Button createPillButton(String label, String hexColor, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setPadding(dp(18), dp(8), dp(18), dp(8));
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(24));
        gd.setColor(Color.parseColor(hexColor));
        btn.setBackground(gd);
        btn.setOnClickListener(listener);
        return btn;
    }

    private interface BoolCallback { void onChanged(boolean value); }
    private interface IntCallback { void onChanged(int value); }

    private View createSwitchRow(String label, boolean initial, BoolCallback cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch sw = new Switch(this);
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((b, isChecked) -> cb.onChanged(isChecked));
        row.addView(sw);
        return row;
    }

    private View createSliderRow(String label, String unit, int initial, int max, IntCallback cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(6), 0, dp(4));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#D9E4FA"));
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        header.addView(lbl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView valTv = new TextView(this);
        valTv.setText(initial + unit);
        valTv.setTextColor(Color.WHITE);
        valTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        header.addView(valTv);
        box.addView(header);

        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(initial);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valTv.setText(progress + unit);
                if (fromUser) cb.onChanged(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(sb);
        return box;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private static final class AmbientOrbBackground extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        AmbientOrbBackground(Activity ctx) {
            super(ctx);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            canvas.drawColor(Color.parseColor("#0A0F1F"));
            drawOrb(canvas, w * 0.18f, h * 0.16f, w * 0.65f, Color.argb(120, 62, 126, 255));
            drawOrb(canvas, w * 0.85f, h * 0.42f, w * 0.60f, Color.argb(105, 146, 84, 255));
            drawOrb(canvas, w * 0.30f, h * 0.85f, w * 0.70f, Color.argb(90, 28, 198, 214));
        }

        private void drawOrb(Canvas canvas, float cx, float cy, float radius, int color) {
            paint.setShader(new RadialGradient(cx, cy, radius, color, Color.TRANSPARENT, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, paint);
        }
    }
}
