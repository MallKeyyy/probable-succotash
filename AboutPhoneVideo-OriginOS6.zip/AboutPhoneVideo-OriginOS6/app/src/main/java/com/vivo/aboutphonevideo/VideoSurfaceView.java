package com.vivo.aboutphonevideo;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.Surface;
import android.view.TextureView;

import de.robv.android.xposed.XposedBridge;

public class VideoSurfaceView extends TextureView implements TextureView.SurfaceTextureListener {
    private final Uri videoUri;
    private final boolean muted;
    private final float volume;

    private MediaPlayer mediaPlayer;
    private Surface surface;
    private int videoWidth = 0;
    private int videoHeight = 0;
    private boolean prepared = false;

    public VideoSurfaceView(Context context, Uri videoUri, boolean muted, int volumePercent) {
        super(context);
        this.videoUri = videoUri;
        this.muted = muted;
        this.volume = Math.max(0f, Math.min(1f, volumePercent / 100f));
        setOpaque(false);
        setSurfaceTextureListener(this);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
        startPlayback(st);
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {
        updateCenterCropTransform(width, height);
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        releasePlayer();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
    }

    public void pausePlayback() {
        try {
            if (mediaPlayer != null && prepared && mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            }
        } catch (Throwable ignored) {}
    }

    public void resumePlayback() {
        try {
            if (mediaPlayer != null && prepared && !mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
        } catch (Throwable ignored) {}
    }

    public void releasePlayer() {
        prepared = false;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
            } catch (Throwable ignored) {}
            try {
                mediaPlayer.release();
            } catch (Throwable ignored) {}
            mediaPlayer = null;
        }
        if (surface != null) {
            try {
                surface.release();
            } catch (Throwable ignored) {}
            surface = null;
        }
    }

    private void startPlayback(SurfaceTexture st) {
        releasePlayer();
        AssetFileDescriptor afd = null;
        try {
            afd = getContext().getContentResolver().openAssetFileDescriptor(videoUri, "r");
            if (afd == null) return;

            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build());
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            surface = new Surface(st);
            mp.setSurface(surface);
            mp.setLooping(true);
            float vol = muted ? 0f : volume;
            mp.setVolume(vol, vol);
            mp.setOnVideoSizeChangedListener((player, w, h) -> {
                videoWidth = w;
                videoHeight = h;
                updateCenterCropTransform(getWidth(), getHeight());
            });
            mp.setOnPreparedListener(player -> {
                prepared = true;
                videoWidth = player.getVideoWidth();
                videoHeight = player.getVideoHeight();
                updateCenterCropTransform(getWidth(), getHeight());
                try {
                    player.start();
                } catch (Throwable ignored) {}
            });
            mp.setOnErrorListener((player, what, extra) -> true);
            mp.prepareAsync();
            mediaPlayer = mp;
        } catch (Throwable t) {
            XposedBridge.log("[AboutPhoneVideo] Playback error (" + videoUri + "): " + t.getMessage());
            releasePlayer();
        } finally {
            if (afd != null) {
                try {
                    afd.close();
                } catch (Throwable ignored) {}
            }
        }
    }

    private void updateCenterCropTransform(int viewW, int viewH) {
        if (viewW <= 0 || viewH <= 0 || videoWidth <= 0 || videoHeight <= 0) return;
        float viewRatio = (float) viewW / (float) viewH;
        float videoRatio = (float) videoWidth / (float) videoHeight;

        float scaleX = 1f;
        float scaleY = 1f;
        if (videoRatio > viewRatio) {
            scaleX = videoRatio / viewRatio;
        } else {
            scaleY = viewRatio / videoRatio;
        }

        Matrix matrix = new Matrix();
        matrix.setScale(scaleX, scaleY, viewW / 2f, viewH / 2f);
        setTransform(matrix);
    }

    @Override
    protected void onDetachedFromWindow() {
        releasePlayer();
        super.onDetachedFromWindow();
    }
}
